<!DOCTYPE html>
<html>

<head>
    <title>Hijrah_Petshop</title>
    <style>
        /* Terapkan gaya dasar pada footer */
        footer {
            background-color: #f2f2f2;
            padding: 14px;
            text-align: center;
            background-image: linear-gradient(89.5deg, rgba(4, 29, 55, 1) -0.1%, rgba(2, 67, 135, 1) 25.1%, rgba(28, 133, 243, 1) 49.6%, rgba(115, 181, 250, 1) 74.5%, rgba(214, 239, 253, 1) 99.3%);

        }

        /* Gaya teks pada elemen paragraf di dalam footer */
        footer p {
            margin: 0;
            /* Hapus margin default agar tidak ada jarak yang tidak diinginkan */
            font-size: 14px;
            color: #666;
            font-style: italic;
        }
    </style>
</head>

<body>
    <footer>
        <p>Hak Cipta &copy; 2023 - Hijrah_Petshop</p>
    </footer>
</body>

</html>