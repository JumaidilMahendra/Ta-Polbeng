<!-- <section class="container">
    <div class="slider-wrapper">
        <div class="slider">
            <img src="img/titip.jpg" alt="">
            <img src="img/titip.jpg" alt="">
            <img src="img/titip.jpg" alt="">
        </div>
        <div class="slider-nav">
            <a href="#slide-1"></a>
            <a href="#slide-2"></a>
            <a href="#slide-3"></a>
        </div>
    </div>
</section>

<style>
    .container {
        padding: 2rem;
        width: 100%;
        height: 50px;
    }

    .slider-wrapper {
        position: relative;
        width: 100%;
        height: 10px;
        margin: auto;
    }

    .slider{
        display: flex;
        aspect-ratio: auto;
        overflow-x: auto;
        scroll-snap-type: x mandatory;
        scroll-behavior: smooth;
        box-shadow: 0 1.5rem 3rem --0.75rem hsla(0, 0%, 0%, 0.25);
    }

    .slider img {

        flex: 20 0;
        scroll-snap-align: start;
        object-fit: cover;
        
    }

    .slider-nav {
        display: flex;
        column-gap: 1rem;
        position: absolute;
        bottom: 1.25rem;
        left: 50%;
        transform: translateX(-50%);
        z-index: 1;
    }

    .slider-nav a {
        width: 0.5rem;
        height: 0.5rem;
        border-radius: 50%;
        background-color: #fff;
        opacity: 0.75;
        transition: opacity ease 250ms;
    }

    .slider-nav a:hover {
        opacity: 1;
    }

</style> -->